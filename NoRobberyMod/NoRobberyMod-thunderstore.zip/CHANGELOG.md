## 1.0.1

Removed some debugging messages

## 1.0.0

Release