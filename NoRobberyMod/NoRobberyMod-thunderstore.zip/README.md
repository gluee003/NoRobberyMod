# NoRobberyMod
No more getting robbed by Megumu. After bribing, defeat her before she escapes to get your money back.